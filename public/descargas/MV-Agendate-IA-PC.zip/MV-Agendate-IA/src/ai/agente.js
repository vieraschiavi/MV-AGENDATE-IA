// Agente conversacional MV Agendate IA.
// Cerebro: Claude (Anthropic) con herramientas de negocio (cotizar, buscar
// horarios con traslados reales, confirmar dirección/receptor, cerrar cita).
// Sin ANTHROPIC_API_KEY corre en MODO DEMO con lógica local — sirve para
// demos sin costo. El oficio y el nombre del profesional se toman de la
// configuración (panel /config.html), así el mismo motor sirve para
// cualquier rubro: electricista, plomero, abogado, psicólogo, etc.
import Anthropic from '@anthropic-ai/sdk';
import { chatearLLM, iaConfigurada, LLMError } from './llm.js';
import { cotizar, cotizarToolDef, listarOficios } from './cotizador.js';
import { geocodificar, geocodificarToolDef } from './geocoding.js';
import { proponerHorarios, proponerHorariosToolDef, configuracionDescansoPorDefecto } from '../store/agenda.js';
import { crearCita, confirmarDireccionCliente, buscarClientePorTelefono, agendaDelDiaConUbicacion } from '../store/trabajos.js';
import { aprobacionRequerida, crearCotizacion, cotizacionDeSesion } from '../store/cotizaciones.js';
import { cuentaActiva } from '../store/contextoCuenta.js';
import { get as cfg, listarProfesionales } from '../store/config.js';
import { registrarUso } from '../store/uso.js';

const telefonoProfesional = () => cfg('agenciaTelefono') || '+598 99 000 000';

// ---------- Profesional seleccionado por sesión (cuentas con varios trabajadores) ----------

const profesionalPorSesion = new Map();

/** Profesional activo de esta conversación: el único configurado, el que ya
 *  eligió el agente con elegir_profesional, o el primero como fallback. */
function profesionalActual(sessionId) {
  const lista = listarProfesionales();
  if (lista.length === 1) return lista[0];
  const id = profesionalPorSesion.get(sessionId);
  return (id && lista.find((p) => p.id === id)) || lista[0];
}

/** Arma la config de descanso/jornada de un profesional puntual (ver store/config.js#listarProfesionales). */
function configuracionDeProfesional(prof) {
  const d = configuracionDescansoPorDefecto;
  const diasLibres = prof.diasLibres;
  return {
    dias_libres: diasLibres ? String(diasLibres).split(',').map(Number).filter((n) => !Number.isNaN(n)) : d.dias_libres,
    horario_laboral: { inicio: prof.horarioInicio || d.horario_laboral.inicio, fin: prof.horarioFin || d.horario_laboral.fin },
    almuerzo: { inicio: prof.almuerzoInicio || d.almuerzo.inicio, fin: prof.almuerzoFin || d.almuerzo.fin },
    buffer_entre_citas_min: d.buffer_entre_citas_min
  };
}

/** true si no hay ninguna API key de IA configurada (respuestas simuladas).
 *  La IA puede ser Claude, ChatGPT (OpenAI) o Gemini — ver src/ai/llm.js. */
export function enModoDemo() { return !iaConfigurada(); }

// ---------- Herramientas de negocio ----------

const confirmarDireccionToolDef = {
  name: 'confirmar_direccion_cliente',
  description:
    'Confirma si el domicilio del trabajo es el mismo que figura en la base del cliente (identificado por su ID o teléfono), o registra la dirección nueva si cambió. Llamala apenas tengas el teléfono/ID del cliente y antes de ofrecer horarios.',
  input_schema: {
    type: 'object',
    properties: {
      clienteId: { type: 'string', description: 'ID del cliente si ya se conoce' },
      telefono: { type: 'string', description: 'Teléfono del cliente (para buscarlo si no hay ID)' },
      direccionInformada: { type: 'string', description: 'Dirección que dio el cliente en este chat' },
      lat: { type: 'number', description: 'Latitud ya resuelta (por geocodificar_direccion o por una ubicación que compartió el cliente)' },
      lng: { type: 'number', description: 'Longitud ya resuelta' }
    }
  }
};

const registrarReceptorToolDef = {
  name: 'registrar_persona_receptora',
  description:
    'Registra si el titular va a estar presente en el domicilio o quién lo va a recibir. Llamala siempre antes de confirmar la cita.',
  input_schema: {
    type: 'object',
    properties: {
      esElTitular: { type: 'boolean' },
      nombreReceptor: { type: 'string', description: 'Nombre de quien atiende si no es el titular' }
    },
    required: ['esElTitular']
  }
};

const confirmarCitaToolDef = {
  name: 'confirmar_cita',
  description:
    'Cierra y guarda la cita en la agenda del profesional, ya con presupuesto, horario, dirección y receptor acordados. Llamala solo al final, cuando el cliente ya aceptó un horario concreto.',
  input_schema: {
    type: 'object',
    properties: {
      clienteNombre: { type: 'string' },
      telefono: { type: 'string' },
      trabajo: { type: 'string', description: 'Clave del tipo de trabajo (ver listarOficios)' },
      fecha: { type: 'string', description: 'YYYY-MM-DD' },
      inicio: { type: 'string', description: 'HH:MM' },
      fin: { type: 'string', description: 'HH:MM' },
      direccion: { type: 'string' },
      direccionConfirmada: { type: 'boolean' },
      lat: { type: 'number', description: 'Latitud del domicilio (de geocodificar_direccion o de la ubicación que compartió el cliente)' },
      lng: { type: 'number', description: 'Longitud del domicilio' },
      receptor: { type: 'string', description: 'Nombre de quien recibe si no es el titular' },
      totalCotizado: { type: 'number' },
      desgloseCotizacion: {
        type: 'object',
        properties: { mano_obra: { type: 'number' }, materiales: { type: 'number' }, traslado: { type: 'number' } }
      }
    },
    required: ['clienteNombre', 'telefono', 'trabajo', 'fecha', 'inicio', 'fin', 'direccion']
  }
};

const elegirProfesionalToolDef = {
  name: 'elegir_profesional',
  description:
    'Registra qué profesional del equipo va a atender este pedido (solo hace falta en cuentas con más de un profesional — vas a ver la lista completa en tus instrucciones). Llamala una sola vez, apenas identifiques cuál corresponde por el oficio pedido o porque el cliente lo nombra, y antes de cotizar.',
  input_schema: {
    type: 'object',
    properties: { profesionalId: { type: 'string', description: 'id del profesional, tal como aparece en la lista de tus instrucciones' } },
    required: ['profesionalId']
  }
};

const TOOLS = [cotizarToolDef, geocodificarToolDef, proponerHorariosToolDef, confirmarDireccionToolDef, registrarReceptorToolDef, confirmarCitaToolDef];

/** Herramientas disponibles para esta conversación: suma elegir_profesional solo si la cuenta tiene más de un profesional. */
function construirTools() {
  return listarProfesionales().length > 1 ? [elegirProfesionalToolDef, ...TOOLS] : TOOLS;
}

async function ejecutarHerramienta(nombre, input, canal, sessionId) {
  const prof = profesionalActual(sessionId);
  const cuenta = cuentaActiva(); // los datos van a la cuenta SaaS activa ('default' en el modo clásico)
  switch (nombre) {
    case 'elegir_profesional': {
      const existe = listarProfesionales().some((p) => p.id === input.profesionalId);
      if (existe) profesionalPorSesion.set(sessionId, input.profesionalId);
      return JSON.stringify({ ok: existe, profesionalId: existe ? input.profesionalId : null });
    }
    case 'cotizar_trabajo': {
      const r = cotizar({ oficio: prof.oficio, ...input });
      if (r.error || !aprobacionRequerida()) return JSON.stringify(r);
      // El precio calculado es un SUGERIDO interno: el cliente no lo ve hasta
      // que el profesional lo apruebe (o ajuste) desde el Panel.
      const previa = await cotizacionDeSesion(sessionId, input.trabajo, cuenta);
      if (previa?.estado === 'aprobada') {
        return JSON.stringify({
          ...r,
          total: previa.totalAprobado,
          aprobado: true,
          nota_del_profesional: previa.nota || undefined,
          instruccion: 'Precio CONFIRMADO por el profesional: informáselo al cliente con su moneda y seguí el flujo normal.'
        });
      }
      if (previa?.estado === 'rechazada') {
        return JSON.stringify({
          requiere_aprobacion: true, estado: 'rechazada', cotizacion_id: previa.id,
          instruccion: 'El profesional prefirió no cotizar esto por chat: NO des ningún monto; decile al cliente que el profesional lo va a contactar directamente y ofrecé el teléfono de contacto.'
        });
      }
      if (previa?.estado === 'pendiente') {
        return JSON.stringify({
          requiere_aprobacion: true, estado: 'pendiente', cotizacion_id: previa.id,
          instruccion: 'Todavía sin confirmar: NO des montos. Decile al cliente que el profesional está confirmando el precio y seguí juntando los demás datos (dirección, teléfono, horarios tentativos).'
        });
      }
      // Teléfono del cliente: en WhatsApp/voz viene en el sessionId (que en el
      // modo SaaS puede llegar prefijado con la cuenta: "cta-xxx/wa:598...").
      const mTel = sessionId.match(/(?:^|\/)(?:wa|tel):(.+)$/);
      const telefono = mTel ? mTel[1] : (input.telefono || '');
      const oficios = listarOficios();
      const datosOficio = oficios.find((o) => o.clave === prof.oficio);
      const cot = await crearCotizacion({
        sessionId, canal, telefono,
        oficio: prof.oficio, oficioNombre: datosOficio?.nombre || prof.oficio,
        trabajo: input.trabajo,
        trabajoNombre: datosOficio?.trabajos.find((t) => t.clave === input.trabajo)?.nombre || input.trabajo,
        detalle: r
      }, cuenta);
      return JSON.stringify({
        requiere_aprobacion: true, estado: 'pendiente', cotizacion_id: cot.id,
        instruccion: 'La cotización quedó en manos del profesional: NO le digas ningún monto al cliente (ni aproximado). Explicale que el profesional confirma el precio enseguida y aprovechá para juntar teléfono y dirección. Cuando pregunte por el precio, volvé a llamar cotizar_trabajo para ver si ya está aprobado.'
      });
    }
    case 'geocodificar_direccion':
      return JSON.stringify(await geocodificar(input.direccion));
    case 'buscar_horarios_disponibles': {
      // Agenda real del día (con ubicación) de ESTE profesional, para calcular
      // el traslado hacia y desde sus citas vecinas — no solo la duración del
      // trabajo nuevo, y sin mezclar la agenda de otros profesionales del equipo.
      const citasDelDia = input.fecha ? await agendaDelDiaConUbicacion(input.fecha, undefined, prof.id, cuenta) : [];
      return JSON.stringify(proponerHorarios({ configuracion: configuracionDeProfesional(prof), ...input, citasDelDia }));
    }
    case 'confirmar_direccion_cliente': {
      let clienteId = input.clienteId;
      if (!clienteId && input.telefono) {
        const cli = await buscarClientePorTelefono(input.telefono, cuenta);
        clienteId = cli?.id;
      }
      if (!clienteId) return JSON.stringify({ ok: true, coincide: null, error: 'Cliente nuevo, no hay dirección previa registrada.' });
      return JSON.stringify(await confirmarDireccionCliente(clienteId, input.direccionInformada, input.lat, input.lng, cuenta));
    }
    case 'registrar_persona_receptora':
      return JSON.stringify({ registrado: true, ...input });
    case 'confirmar_cita': {
      const oficios = listarOficios();
      const datosOficio = oficios.find((o) => o.clave === prof.oficio);
      const trabajoNombre = datosOficio?.trabajos.find((t) => t.clave === input.trabajo)?.nombre || input.trabajo;
      const cita = await crearCita({
        clienteNombre: input.clienteNombre,
        telefono: input.telefono,
        profesionalId: prof.id,
        oficio: prof.oficio,
        oficioNombre: datosOficio?.nombre || prof.oficio,
        trabajo: input.trabajo,
        trabajoNombre,
        fecha: input.fecha,
        inicio: input.inicio,
        fin: input.fin,
        direccion: input.direccion,
        direccionConfirmada: !!input.direccionConfirmada,
        lat: input.lat,
        lng: input.lng,
        receptor: input.receptor,
        cotizacion: input.totalCotizado != null ? { ...input.desgloseCotizacion, total: input.totalCotizado } : null,
        canal
      }, cuenta);
      return JSON.stringify({ ok: true, cita, mensaje: `Cita confirmada para el ${cita.fecha} a las ${cita.inicio}.` });
    }
    default:
      return `Herramienta desconocida: ${nombre}`;
  }
}

// ---------- Prompt del agente ----------

function buildSystem(sessionId) {
  const lista = listarProfesionales();
  const multiple = lista.length > 1;
  const prof = profesionalActual(sessionId);
  const marca = cfg('agenciaNombre') || cfg('nombreProfesional') || 'nuestro equipo';
  const intro = multiple
    ? `Sos el asistente virtual de ${marca}, un equipo con varios profesionales. Estos son los profesionales disponibles (id: nombre — oficio):\n${lista.map((p) => `- ${p.id}: ${p.nombre} — ${p.oficio}`).join('\n')}\nApenas identifiques por el pedido del cliente (o porque lo nombra) cuál corresponde, llamá a elegir_profesional con su id — una sola vez, antes de cotizar.`
    : `Sos el asistente virtual de ${prof.nombre}, que trabaja como ${prof.oficio}.`;
  return `${intro} Atendés clientes por WhatsApp, voz y webchat que quieren pedir un trabajo o servicio.

Flujo esperado en cada conversación:
1. Entendé qué necesita el cliente y a qué tipo de trabajo predefinido corresponde. Usá cotizar_trabajo apenas lo sepas — nunca inventes precios.
2. REGLA DE ORO del precio: la cotización es un sugerido que SIEMPRE aprueba el profesional. Si cotizar_trabajo devuelve requiere_aprobacion=true con estado "pendiente", NO menciones ningún monto (ni rango, ni aproximado): decile al cliente que el profesional le confirma el precio en unos minutos y seguí avanzando con los pasos 3-5 mientras tanto. Cuando el cliente pregunte por el precio, o antes de cerrar la cita, volvé a llamar cotizar_trabajo: solo cuando devuelva aprobado=true informá ese precio confirmado. Si devuelve el presupuesto directo (sin requiere_aprobacion), daselo antes de ofrecer horarios como siempre. Nunca confirmes una cita sin precio informado al cliente.
3. Pedí el teléfono y la dirección. Si el cliente comparte su UBICACIÓN (vas a ver algo como "[Ubicación compartida: lat X, lng Y — dirección aproximada: ...]" en su mensaje), esas coordenadas ya son exactas: no hace falta geocodificarlas, usalas directo. Si en cambio escribe la dirección a mano, pasala por geocodificar_direccion para obtener sus coordenadas antes de ofrecer horarios.
4. Confirmá la dirección con confirmar_direccion_cliente (pasale también lat/lng si ya los tenés) — si cambió respecto a la base, listo, ya quedó actualizada.
5. Preguntá si el titular va a estar presente; si no, registrá con registrar_persona_receptora el nombre de quien va a atender.
6. Ofrecé 2-3 horarios concretos con buscar_horarios_disponibles (necesita fecha, día de la semana, duración del trabajo y las coordenadas del cliente) — nunca preguntes "¿cuándo te queda bien?" en abstracto.
7. Cuando el cliente acepte un horario, cerrá todo con confirmar_cita (incluí lat/lng si los tenés, así queda guardado para la próxima vez).

Moneda y forma de cobro: cotizar_trabajo devuelve la moneda configurada (campo "moneda"/"simbolo") — mencioná siempre los montos con esa moneda, sin convertir. Si el resultado dice tipo_cobro "honorarios" (servicios profesionales: médicos, abogados, escribanos, psicólogos, contadores…), hablá de "honorarios profesionales", nunca de "mano de obra".

Tono y estilo: profesional pero cercano, español rioplatense (vos/tenés), claro y sin exclamaciones exageradas. Emojis con moderación (uno como máximo, o ninguno). Respuestas cortas tipo chat: 2-5 oraciones. En WhatsApp y voz, aún más breve. Si el trabajo no encaja en ningún tipo predefinido, decilo con honestidad y ofrecé una visita de diagnóstico. Si preguntan algo fuera del rubro, redirigí con amabilidad y ofrecé el teléfono ${telefonoProfesional()} para casos urgentes.`;
}

// ---------- Sesiones en memoria por canal+usuario ----------

const sesiones = new Map();
const MAX_TURNOS = 40;

/**
 * Recorta el historial sin romper pares tool_use/tool_result: el corte solo
 * puede caer en un mensaje de usuario con texto plano (inicio de turno real).
 */
export function recortarHistorial(mensajes, max = MAX_TURNOS) {
  if (mensajes.length <= max) return mensajes;
  for (let i = mensajes.length - max; i < mensajes.length; i++) {
    if (mensajes[i].role === 'user' && typeof mensajes[i].content === 'string') {
      return mensajes.slice(i);
    }
  }
  return mensajes;
}

function historial(sessionId) {
  if (!sesiones.has(sessionId)) sesiones.set(sessionId, []);
  return sesiones.get(sessionId);
}

// ---------- Modo demo (sin API key) ----------
// Respuestas locales sin costo, para mostrar el flujo cuando no hay clave de
// Claude configurada. IMPORTANTE: nunca filtra detalles internos del servidor
// (ni "modo demo", ni "cargá tu clave") — el visitante ve un asistente normal.
// Para respuestas con IA real, configurá ANTHROPIC_API_KEY (env de Vercel o
// /config.html). El badge solo aparece si pedís DEMO_CON_BADGE=1 (uso interno).
const BADGE = process.env.DEMO_CON_BADGE ? '⚙️ [demo] ' : '';

// Estado mínimo por sesión para que la demo (sin IA) avance como una charla real.
const demoSesiones = new Map();
const norm = (s) => String(s ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');

// Sinónimos coloquiales → clave de trabajo (por oficio, solo si esa clave existe).
const SINONIMOS = {
  instalacion_toma: ['toma', 'tomacorriente', 'tomacorrientes', 'enchufe', 'enchufes', 'zocalo'],
  instalacion_luminaria: ['luz', 'luces', 'lampara', 'foco', 'luminaria', 'artefacto', 'plafon', 'spot', 'aplique', 'dicroica'],
  cambio_tablero: ['tablero', 'termica', 'llave termica', 'disyuntor', 'breaker', 'diferencial'],
  cortocircuito: ['corto', 'cortocircuito', 'chispa', 'se corta la luz', 'salta la llave', 'no hay luz', 'huele a quemado'],
  diagnostico: ['diagnostico', 'revisar', 'revision', 'ver que pasa', 'presupuesto general'],
  destape: ['destap', 'tapado', 'tapada', 'canaleta'],
  perdida: ['perdida', 'gotea', 'gotera', 'fuga', 'pierde agua'],
};

/** Detecta el trabajo pedido dentro del catálogo del oficio (sinónimos + tokens del nombre). */
function detectarTrabajo(oficio, texto) {
  const t = norm(texto);
  for (const [clave, palabras] of Object.entries(SINONIMOS)) {
    if (oficio.trabajos.some((tr) => tr.clave === clave) && palabras.some((p) => t.includes(p))) return clave;
  }
  for (const tr of oficio.trabajos) {
    const toks = norm(tr.nombre).split(/[^a-z0-9]+/).filter((w) => w.length >= 5);
    if (toks.some((w) => t.includes(w))) return tr.clave;
  }
  return null;
}

const tieneDireccion = (t) => /\d{2,}/.test(t) && /[a-záéíóú]{3,}/i.test(t) && !/(cuanto|precio|cuesta|sale)/i.test(t);
const quiereHorario = (t) => /(turno|horario|agend|cita|cuando|dispon|manana|mañana|semana|lunes|martes|miercoles|jueves|viernes|sabado|hoy|tarde)/.test(norm(t));
const confirma = (t) => /(^| )(si|dale|listo|confirm|de una|perfecto|va|ok|okey)( |$|\.|,|!)/.test(norm(t));
const saluda = (t) => /(hola|buenas|buen dia|buenos dias|buenas tardes|buenas noches|que tal)/.test(norm(t));

function responderDemo(sessionId, texto, canal) {
  const prof = listarProfesionales()[0];
  const oficios = listarOficios();
  const propio = oficios.find((o) => o.clave === prof.oficio) || oficios[0];
  const st = demoSesiones.get(sessionId) || {};
  const t = norm(texto);
  const nombreServicio = (clave) => propio.trabajos.find((x) => x.clave === clave)?.nombre || 'el trabajo';
  const cotizarDe = (clave) => cotizar({ oficio: propio.clave, trabajo: clave, distanciaKm: 5 });
  const guardar = () => demoSesiones.set(sessionId, st);

  // 1) ¿Menciona un trabajo? Cotizamos ESE (no siempre el primero).
  const trabajo = detectarTrabajo(propio, texto);
  if (trabajo) st.trabajo = trabajo;

  // 2) ¿Dio una dirección?
  if (tieneDireccion(texto)) st.direccion = texto.trim();

  // Helper: proponer horarios (cuando ya sabemos el trabajo).
  const proponerSlots = () => {
    st.propuso = true; guardar();
    const dir = st.direccion ? ` en ${st.direccion}` : '';
    return `${BADGE}Genial. Para "${nombreServicio(st.trabajo)}"${dir} tengo estos horarios: mañana 9:30–10:30, mañana 15:00–16:00 o pasado 11:00–12:00. ¿Cuál te queda mejor? (Los calculamos considerando el traslado hasta tu zona.)`;
  };

  // Confirmó un horario ya propuesto → cerramos (demo).
  if (st.propuso && confirma(texto)) {
    demoSesiones.delete(sessionId);
    return `${BADGE}¡Listo! Quedó agendado ✅ Te llega la confirmación por WhatsApp y, si el profesional se demora, te avisamos antes. ¡Gracias! (Demo — en la versión real esto queda cargado en la agenda y el CRM.)`;
  }

  // Pidió/mencionó un trabajo → cotizamos y encaminamos hacia el horario.
  if (trabajo || (st.trabajo && /(cuanto|precio|presupuesto|cotiz|cuesta|sale)/.test(t))) {
    const r = cotizarDe(st.trabajo);
    st.cotizado = true; guardar();
    const sig = st.direccion ? ' ¿Te propongo horarios?' : ' Pasame tu dirección y qué día te viene bien, y te doy 2-3 horarios.';
    return `${BADGE}"${r.trabajo}" ronda los ${r.simbolo || '$'}${r.total} (${r.moneda}), con una duración estimada de ${r.duracion_estimada_min} min. El precio final lo confirma ${prof.nombre}.${sig}`;
  }

  // Pidió horario: si ya sabemos el trabajo, proponemos; si no, lo pedimos.
  if (quiereHorario(texto)) {
    if (st.trabajo) return proponerSlots();
    guardar();
    return `${BADGE}Con gusto coordino. ¿Qué trabajo necesitás? (por ejemplo: instalar un tomacorriente, colocar una luminaria, revisar el tablero). Con eso y tu dirección te propongo horarios.`;
  }

  // Dio dirección sin trabajo aún.
  if (st.direccion && !st.trabajo) {
    guardar();
    return `${BADGE}¡Anotada la dirección! ¿Qué necesitás que haga ${prof.nombre}? Contame el trabajo y te paso presupuesto y horarios.`;
  }

  if (saluda(texto) || !texto.trim()) {
    return `${BADGE}¡Hola! Soy el asistente de ${prof.nombre} (${propio?.nombre || prof.oficio}). Contame qué necesitás —por ejemplo "instalar un tomacorriente"— y te paso presupuesto y horarios. 😊`;
  }

  // No entendimos el trabajo: ofrecemos ejemplos reales del catálogo.
  const ejemplos = propio.trabajos.slice(0, 3).map((x) => `“${x.nombre}”`).join(', ');
  guardar();
  return `${BADGE}Puedo ayudarte con trabajos como ${ejemplos}. Decime cuál necesitás (o contame el problema) y te paso presupuesto y horarios.`;
}

// ---------- Conversación con Claude ----------

/**
 * Procesa un mensaje del cliente y devuelve la respuesta del agente.
 * @param {string} sessionId — identificador estable del cliente (ej: wa:+598..., web:uuid, tel:+598...)
 * @param {string} texto — mensaje del cliente
 * @param {string} canal — 'webchat' | 'whatsapp' | 'telefono' | 'voz'
 */
export async function conversar(sessionId, texto, canal = 'webchat') {
  if (!iaConfigurada()) return responderDemo(sessionId, texto, canal);

  // En el modo SaaS las sesiones se aíslan por cuenta: el mismo cliente
  // (wa:598...) hablando con dos profesionales distintos son DOS charlas.
  if (cuentaActiva() !== 'default' && !sessionId.startsWith(`${cuentaActiva()}/`)) {
    sessionId = `${cuentaActiva()}/${sessionId}`;
  }
  const mensajes = historial(sessionId);
  const marcaTurno = mensajes.length;
  mensajes.push({ role: 'user', content: texto });

  try {
    let respuesta;
    for (let i = 0; i < 8; i++) {
      respuesta = await chatearLLM({
        system: buildSystem(sessionId),
        tools: construirTools(),
        mensajes
      });
      registrarUso(respuesta.usage, canal);

      mensajes.push({ role: 'assistant', content: respuesta.content });

      if (respuesta.stop_reason === 'tool_use') {
        const resultados = await Promise.all(
          respuesta.content
            .filter((b) => b.type === 'tool_use')
            .map(async (b) => ({
              type: 'tool_result',
              tool_use_id: b.id,
              content: await ejecutarHerramienta(b.name, b.input, canal, sessionId)
            }))
        );
        mensajes.push({ role: 'user', content: resultados });
        continue;
      }
      break;
    }

    if (mensajes.length > MAX_TURNOS) sesiones.set(sessionId, recortarHistorial(mensajes));

    const textos = respuesta.content.filter((b) => b.type === 'text').map((b) => b.text);
    return textos.join('\n') || 'Disculpá, ¿me lo repetís?';
  } catch (err) {
    sesiones.set(sessionId, mensajes.slice(0, marcaTurno));
    if (err instanceof Anthropic.RateLimitError) {
      return 'Estamos con mucha demanda en este momento. Probá de nuevo en unos segundos 🙏';
    }
    if (err instanceof Anthropic.APIConnectionError) {
      return `Tuve un problema de conexión. Si es urgente, llamanos al ${telefonoProfesional()}.`;
    }
    // Cualquier error de la IA (Claude/OpenAI/Gemini): no romper la conversación.
    if (err instanceof Anthropic.APIError || err instanceof LLMError) {
      console.error('[agente] Error de IA:', err.status || '', err.message);
      return `Tuve un inconveniente técnico. Un agente humano puede ayudarte al ${telefonoProfesional()}.`;
    }
    console.error('[agente] Error inesperado:', err?.message || err);
    return `Tuve un inconveniente técnico. Un agente humano puede ayudarte al ${telefonoProfesional()}.`;
  }
}

export { TOOLS, construirTools, listarOficios };
