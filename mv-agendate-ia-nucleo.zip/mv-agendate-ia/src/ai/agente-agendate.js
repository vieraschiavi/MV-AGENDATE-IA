// Agente conversacional MV Agendate IA
//
// Mismo patrón que src/ai/agente.js del proyecto "MV Asistente Inmobiliario":
// un loop de tool-calling con el SDK de Claude, memoria de conversación por
// sessionId, y funciona en modo demo (sin API key) para no romper la demo
// pública. La diferencia es el set de herramientas: acá el agente cotiza
// trabajos por oficio y arma la agenda en vez de tasar propiedades.
//
// Integra con cualquier canal (WhatsApp, voz, webchat) llamando siempre a
// conversar(sessionId, texto, canal) — igual que channels/whatsapp.js y
// channels/voz.js ya hacen en el proyecto base.

import Anthropic from '@anthropic-ai/sdk';
import { cotizar, cotizarToolDef, listarOficios } from './cotizador.js';
import { proponerHorarios, proponerHorariosToolDef } from '../store/agenda.js';

const MODELO_DEFECTO = 'claude-haiku-4-5-20251001'; // rápido y barato para diálogo de WhatsApp
const MODELO_COMPLEJO = 'claude-sonnet-5'; // para cotizaciones ambiguas o negociación de horarios difícil

const anthropic = process.env.ANTHROPIC_API_KEY
  ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
  : null;

// Memoria de conversación en proceso (para producción real: mover a Redis /
// disco, igual que hace store/config.js en el proyecto base con /tmp).
const sesiones = new Map();

const confirmarDireccionToolDef = {
  name: 'confirmar_direccion_cliente',
  description:
    'Confirma si el trabajo es en la misma dirección que figura en la base de datos del cliente, o pide la dirección nueva si cambió.',
  input_schema: {
    type: 'object',
    properties: {
      direccionEnBase: { type: 'string' },
      direccionConfirmadaPorCliente: { type: 'string' },
      coincide: { type: 'boolean' },
    },
    required: ['coincide'],
  },
};

const registrarReceptorToolDef = {
  name: 'registrar_persona_receptora',
  description:
    'Registra el nombre de la persona que va a recibir al profesional en el domicilio, cuando no es el titular de la cuenta quien va a estar presente.',
  input_schema: {
    type: 'object',
    properties: {
      esElTitular: { type: 'boolean' },
      nombreReceptor: { type: 'string', description: 'Nombre de quien atiende si no es el titular' },
    },
    required: ['esElTitular'],
  },
};

const TOOLS = [cotizarToolDef, proponerHorariosToolDef, confirmarDireccionToolDef, registrarReceptorToolDef];

function ejecutarTool(nombre, input) {
  switch (nombre) {
    case 'cotizar_trabajo':
      return cotizar(input);
    case 'buscar_horarios_disponibles':
      return proponerHorarios(input);
    case 'confirmar_direccion_cliente':
      return { registrado: true, ...input };
    case 'registrar_persona_receptora':
      return { registrado: true, ...input };
    default:
      return { error: `Tool desconocida: ${nombre}` };
  }
}

function promptDeSistema(oficioProfesional, nombreProfesional) {
  return (
    `Sos el asistente virtual de ${nombreProfesional || 'este profesional'}, que trabaja como ${oficioProfesional}. ` +
    `Atendés por WhatsApp o por voz a clientes que quieren pedir un trabajo. Tu forma de hablar es cercana, ` +
    `rioplatense, profesional pero no acartonada.\n\n` +
    `Flujo esperado:\n` +
    `1) Entendé qué necesita el cliente y a qué categoría de trabajo corresponde (usá cotizar_trabajo apenas lo sepas).\n` +
    `2) Dale el presupuesto estimado ANTES de ofrecer horarios.\n` +
    `3) Preguntá la dirección y confirmá si es la misma que la de la base (confirmar_direccion_cliente).\n` +
    `4) Preguntá si el titular va a estar presente; si no, pedí el nombre de quien va a atender (registrar_persona_receptora).\n` +
    `5) Ofrecé 2-3 horarios concretos usando buscar_horarios_disponibles, no le preguntes "¿cuándo te queda bien?" en abstracto.\n` +
    `6) Confirmá la cita con fecha, hora, dirección y presupuesto por escrito al final.\n\n` +
    `Nunca inventes precios que no vengan de cotizar_trabajo. Si el trabajo no encaja en ningún tipo predefinido, decilo con honestidad y ofrecé una visita de diagnóstico.`
  );
}

/**
 * @param {string} sessionId
 * @param {string} texto - mensaje del cliente
 * @param {string} canal - "whatsapp" | "voz" | "webchat"
 * @param {object} contexto - { oficioProfesional, nombreProfesional }
 */
export async function conversar(sessionId, texto, canal, contexto = {}) {
  if (!anthropic) {
    return modoDemo(texto, contexto);
  }

  const historial = sesiones.get(sessionId) || [];
  historial.push({ role: 'user', content: texto });

  let respuestaFinal = '';
  let mensajes = historial;
  const modelo = /presupuesto complejo|varios trabajos|no está seguro/i.test(texto)
    ? MODELO_COMPLEJO
    : MODELO_DEFECTO;

  // Loop de tool-calling: Claude puede pedir varias herramientas antes de responder en texto.
  for (let vuelta = 0; vuelta < 4; vuelta++) {
    const respuesta = await anthropic.messages.create({
      model: modelo,
      max_tokens: 700,
      system: promptDeSistema(contexto.oficioProfesional, contexto.nombreProfesional),
      tools: TOOLS,
      messages: mensajes,
    });

    const usoTool = respuesta.content.find((b) => b.type === 'tool_use');
    const textoBloque = respuesta.content.find((b) => b.type === 'text');

    if (usoTool) {
      const resultado = ejecutarTool(usoTool.name, usoTool.input);
      mensajes = [
        ...mensajes,
        { role: 'assistant', content: respuesta.content },
        { role: 'user', content: [{ type: 'tool_result', tool_use_id: usoTool.id, content: JSON.stringify(resultado) }] },
      ];
      continue; // Claude ve el resultado y decide el próximo paso
    }

    respuestaFinal = textoBloque?.text || '';
    mensajes = [...mensajes, { role: 'assistant', content: respuesta.content }];
    break;
  }

  sesiones.set(sessionId, mensajes);
  return respuestaFinal;
}

// Respuestas de ejemplo sin API key, para poder probar la demo sin gastar tokens.
function modoDemo(texto, contexto) {
  const oficios = listarOficios();
  return (
    `[Modo demo — sin ANTHROPIC_API_KEY cargada]\n` +
    `Acá el agente real entendería tu pedido y cotizaría con precios de ${contexto.oficioProfesional || 'el oficio configurado'}. ` +
    `Oficios cargados en este demo: ${oficios.map((o) => o.nombre).join(', ')}.`
  );
}
